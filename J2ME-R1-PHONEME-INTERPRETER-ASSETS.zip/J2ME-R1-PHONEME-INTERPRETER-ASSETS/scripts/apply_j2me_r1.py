#!/usr/bin/env python3
from pathlib import Path
import sys, shutil
up=Path(sys.argv[1]).resolve()
asset=Path(__file__).resolve().parents[1]
app=up/'src/emu/ios/app'
jdir=app/'j2me'
if jdir.exists(): shutil.rmtree(jdir)
shutil.copytree(asset/'integration/app/j2me',jdir)

cm=up/'src/emu/ios/CMakeLists.txt'
t=cm.read_text()
marker='# J2ME R1 PHONEME INTERPRETER'
if marker in t: raise SystemExit('J2ME R1 already applied')
anchor='    app/RootViewController.h\n    app/RootViewController.mm)'
if t.count(anchor)!=1: raise SystemExit(f'CMake source anchor count={t.count(anchor)}')
sources='''    app/j2me/J2MEBridge.h\n    app/j2me/J2MEBridge.mm\n    app/j2me/J2MEProfile.hpp\n    app/j2me/J2MEJarMetadata.h\n    app/j2me/J2MEJarMetadata.mm\n    app/j2me/J2MEJarReader.hpp\n    app/j2me/J2MEJarReader.cpp\n    app/j2me/J2MEProfileStore.h\n    app/j2me/J2MEProfileStore.mm\n    app/j2me/J2MEProfileViewController.h\n    app/j2me/J2MEProfileViewController.mm\n    app/j2me/J2MEKeypadView.h\n    app/j2me/J2MEKeypadView.mm\n    app/j2me/J2MEPlayerViewController.h\n    app/j2me/J2MEPlayerViewController.mm\n    app/j2me/J2MELibraryViewController.h\n    app/j2me/J2MELibraryViewController.mm\n'''
t=t.replace(anchor,sources+anchor,1)
link_anchor='add_executable(eka2l1 MACOSX_BUNDLE ${IOS_APP_SOURCES})\n'
if t.count(link_anchor)!=1: raise SystemExit('CMake executable anchor missing')
addon='''add_executable(eka2l1 MACOSX_BUNDLE ${IOS_APP_SOURCES})\n# J2ME R1 PHONEME INTERPRETER\nset(PHONEME_R1_ROOT "${PROJECT_SOURCE_DIR}/third_party/phoneme-r1")\nset(PHONEME_R1_LIB "${PHONEME_R1_ROOT}/lib/libphoneMECore.a")\ntarget_include_directories(eka2l1 PRIVATE "${PHONEME_R1_ROOT}/include" "${CMAKE_CURRENT_SOURCE_DIR}/app/j2me")\ntarget_link_libraries(eka2l1 PRIVATE "${PHONEME_R1_LIB}" z iconv "-framework CoreText" "-framework CoreGraphics" "-framework CoreFoundation" "-framework ImageIO")\ntarget_link_options(eka2l1 PRIVATE "-Wl,-force_load,${PHONEME_R1_LIB}")\n'''
t=t.replace(link_anchor,addon,1)
cm.write_text(t)

root=app/'RootViewController.mm'
r=root.read_text()
imp='#import "J2MELibraryViewController.h"'
if imp not in r:
    anchor='#import "SyncViewController.h"\n'
    if r.count(anchor)!=1: raise SystemExit('Root import anchor missing')
    r=r.replace(anchor,anchor+'#import "j2me/J2MELibraryViewController.h"\n',1)
method='''// J2ME R1 PHONEME INTERPRETER\n- (void)onJavaJ2ME {\n    J2MELibraryViewController *vc = [J2MELibraryViewController new];\n    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];\n    nav.modalPresentationStyle = UIModalPresentationFullScreen;\n    vc.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemClose target:self action:@selector(closeJavaJ2ME:)];\n    [self presentViewController:nav animated:YES completion:nil];\n}\n- (void)closeJavaJ2ME:(id)sender { [self dismissViewControllerAnimated:YES completion:nil]; }\n'''
setup='- (void)setupToolbar {'
if method not in r:
    if r.count(setup)!=1: raise SystemExit(f'Root setupToolbar anchor count={r.count(setup)}')
    r=r.replace(setup,method+setup,1)
button_marker='@selector(onJavaJ2ME)'
if button_marker not in r:
    # Add the button immediately before the toolbar is attached to the root view.
    anchor='    [self.view addSubview:self.toolbar];\n'
    if r.count(anchor)!=1: raise SystemExit(f'Root toolbar add anchor count={r.count(anchor)}')
    button='''    UIButton *javaButton = [UIButton buttonWithType:UIButtonTypeSystem];\n    [javaButton setTitle:@"Java" forState:UIControlStateNormal];\n    [javaButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];\n    javaButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];\n    [javaButton addTarget:self action:@selector(onJavaJ2ME) forControlEvents:UIControlEventTouchUpInside];\n    [self.toolbar addSubview:javaButton];\n'''
    r=r.replace(anchor,button+anchor,1)
root.write_text(r)

# Guard: R3 CODEMAP1 files are read-only to this installer.
for rel in ['src/emu/mem/src/model/flexible/control.cpp','src/emu/kernel/src/libmanager.cpp']:
    if not (up/rel).exists(): raise SystemExit(f'R3 guard missing {rel}')
print('J2ME R1 source integration applied without touching R3 CODEMAP1 files')
