#!/usr/bin/env bash
set -euo pipefail
UPSTREAM="${1:?usage: install-j2me-r1.sh /path/to/upstream [build-dir]}"
BUILD="${2:-${RUNNER_TEMP:-/tmp}/phoneme-core-r1}"
ASSET_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CORE="$ASSET_ROOT/phoneME/Core"
STAGE="$UPSTREAM/third_party/phoneme-r1"
rm -rf "$STAGE" "$BUILD"
mkdir -p "$STAGE/lib" "$STAGE/include"
PHONEME_CORE_BUILD_DIR="$BUILD" PHONEME_CORE_OUTPUT="$STAGE/lib/libphoneMECore.a" PHONEME_APPLE_SDK=iphoneos IOS_DEPLOYMENT_TARGET=15.0 PHONEME_ENABLE_DECODED_EXECUTION=1 PHONEME_ENABLE_THINLTO=0 bash "$CORE/Tools/build-iphoneos.sh"
PHONEME_CORE_BUILD_DIR="$BUILD" PHONEME_CORE_OUTPUT="$STAGE/lib/libphoneMECore.a" PHONEME_APPLE_SDK=iphoneos IOS_DEPLOYMENT_TARGET=15.0 PHONEME_ENABLE_DECODED_EXECUTION=1 PHONEME_ENABLE_THINLTO=0 bash "$CORE/Tools/verify-iphoneos.sh"
cp -R "$CORE/include/." "$STAGE/include/"
python3 "$ASSET_ROOT/scripts/apply_j2me_r1.py" "$UPSTREAM"
test -s "$STAGE/lib/libphoneMECore.a"
grep -Fq 'J2ME R1 PHONEME INTERPRETER' "$UPSTREAM/src/emu/ios/CMakeLists.txt"
grep -Fq 'onJavaJ2ME' "$UPSTREAM/src/emu/ios/app/RootViewController.mm"
grep -Fq 'code_sec_(ram_code_addr, dll_static_data_flexible, page_size())' "$UPSTREAM/src/emu/mem/src/model/flexible/control.cpp"
grep -Fq 'EPOC94 ROM-first SysBin policy enabled' "$UPSTREAM/src/emu/kernel/src/libmanager.cpp"
git -C "$UPSTREAM" diff --check
echo 'J2ME R1 PHONEME INTERPRETER asset installation: PASS'
