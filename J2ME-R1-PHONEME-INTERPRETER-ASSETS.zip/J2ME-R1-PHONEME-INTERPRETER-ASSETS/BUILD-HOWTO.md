# Build with the companion GitHub Actions workflow

Repository placement:

```
<repo>/
├── J2ME-R1-PHONEME-INTERPRETER-ASSETS.zip
└── .github/
    └── workflows/
        └── build-ios-ngage-classic-r3-j2me-r1-phoneme-interpreter.yml
```

Alternative ZIP location accepted by the workflow:

```
<repo>/.github/build-assets/J2ME-R1-PHONEME-INTERPRETER-ASSETS.zip
```

Then run the workflow manually, or push either the workflow or the ZIP to `main`.

The workflow derives from R3 RM612 CODEMAP1 FIX1. It does not edit or replace the R3 workflow file. J2ME is added after the R3 source patches and before the final iOS CMake configure/build.

The ZIP is self-contained for J2ME R1: pinned phoneME Core source, GPLv3 license, C ABI header, C++17 EKA2L1 bridge/UI, JAR reader, resolution/profile system and installation scripts. No network clone of phoneME is required during the build.
