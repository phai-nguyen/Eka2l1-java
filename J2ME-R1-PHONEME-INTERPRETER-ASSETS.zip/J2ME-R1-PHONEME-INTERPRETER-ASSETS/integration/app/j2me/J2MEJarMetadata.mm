#import "J2MEJarMetadata.h"
#include "J2MEJarReader.hpp"

NSDictionary *J2MEInspectJarAtPath(NSString *path, NSError **error) {
    eka2l1::ios::j2me::JarMetadata m;
    std::string why;
    if (!eka2l1::ios::j2me::inspect_jar(path.UTF8String ?: "", m, why)) {
        if (error) {
            NSString *msg=[NSString stringWithUTF8String:why.c_str()] ?: @"Invalid JAR";
            *error=[NSError errorWithDomain:@"EKA2L1.J2ME" code:-20 userInfo:@{NSLocalizedDescriptionKey:msg}];
        }
        return nil;
    }
    auto ns=[](const std::string &s)->NSString * { return [NSString stringWithUTF8String:s.c_str()] ?: @""; };
    return @{ @"name":ns(m.name), @"vendor":ns(m.vendor), @"version":ns(m.version),
              @"mainClass":ns(m.main_class), @"profile":ns(m.profile),
              @"configuration":ns(m.configuration), @"iconPath":ns(m.icon_path) };
}
