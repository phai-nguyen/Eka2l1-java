#pragma once
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@interface J2MEKeypadView : UIView
@property(nonatomic,copy) void (^onKey)(int32_t key, BOOL down);
@end
NS_ASSUME_NONNULL_END
