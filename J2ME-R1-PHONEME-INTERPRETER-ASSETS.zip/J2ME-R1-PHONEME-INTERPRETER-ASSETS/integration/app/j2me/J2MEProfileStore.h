#pragma once
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSMutableDictionary *J2MEDefaultProfile(void);
FOUNDATION_EXPORT NSMutableDictionary *J2MELoadProfile(NSString *gameID);
FOUNDATION_EXPORT BOOL J2MESaveProfile(NSString *gameID, NSDictionary *profile, NSError **error);
FOUNDATION_EXPORT NSString *J2MEProfileSummary(NSDictionary *profile);
NS_ASSUME_NONNULL_END
