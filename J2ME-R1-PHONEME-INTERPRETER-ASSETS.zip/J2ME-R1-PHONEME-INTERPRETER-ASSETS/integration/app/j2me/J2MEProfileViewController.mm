#import "J2MEProfileViewController.h"

static NSArray<NSString *> *J2MEResolutionPresets(void) { return @[@"128×128",@"128×160",@"132×176",@"176×220",@"240×320",@"352×416",@"640×360",@"800×480"]; }
static NSArray<NSString *> *J2MEScaleTypes(void) { return @[@"As-is",@"Fit",@"Fill"]; }
static NSArray<NSString *> *J2MEOrientations(void) { return @[@"Default",@"Auto",@"Portrait",@"Landscape"]; }
static NSArray<NSString *> *J2MEGravities(void) { return @[@"Left",@"Top",@"Center",@"Right",@"Bottom"]; }

@implementation J2MEProfileViewController
- (void)viewDidLoad { [super viewDidLoad]; self.title=@"Java display"; self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveNow)]; }
- (void)saveNow { if (self.onSave) self.onSave([self.profile copy]); [self.navigationController popViewControllerAnimated:YES]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)t { return 3; }
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)s { return s==0?4:(s==1?7:2); }
- (NSString *)tableView:(UITableView *)t titleForHeaderInSection:(NSInteger)s { return s==0?@"Logical MIDlet screen":(s==1?@"Presentation":@"Input"); }
- (UITableViewCell *)switchCell:(NSString *)title key:(NSString *)key {
    UITableViewCell *c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil]; c.textLabel.text=title;
    UISwitch *sw=[UISwitch new]; sw.on=self.profile[key]?[self.profile[key] boolValue]:NO; sw.tag=[@[@"preserveAspect",@"filtering",@"forceFullscreen",@"showFPS",@"touchInput",@"showKeypad"] indexOfObject:key]+100;
    [sw addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged]; c.accessoryView=sw; return c;
}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil]; c.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    if(ip.section==0){
        if(ip.row==0){c.textLabel.text=@"Resolution";c.detailTextLabel.text=[NSString stringWithFormat:@"%@×%@",self.profile[@"screenWidth"],self.profile[@"screenHeight"]];}
        if(ip.row==1){c.textLabel.text=@"Custom width/height";c.detailTextLabel.text=@"1–2048";}
        if(ip.row==2){c.textLabel.text=@"Swap width ↔ height";c.accessoryType=UITableViewCellAccessoryNone;}
        if(ip.row==3){c.textLabel.text=@"Scale";c.detailTextLabel.text=[NSString stringWithFormat:@"%@%%",self.profile[@"scalePercent"]];}
    } else if(ip.section==1){
        if(ip.row==0){c.textLabel.text=@"Scale type";c.detailTextLabel.text=self.profile[@"scaleType"];}
        if(ip.row==1)return [self switchCell:@"Keep aspect ratio" key:@"preserveAspect"];
        if(ip.row==2){c.textLabel.text=@"Orientation";c.detailTextLabel.text=self.profile[@"orientation"];}
        if(ip.row==3){c.textLabel.text=@"Gravity";c.detailTextLabel.text=self.profile[@"gravity"];}
        if(ip.row==4)return [self switchCell:@"Image filtering" key:@"filtering"];
        if(ip.row==5)return [self switchCell:@"Force Canvas fullscreen" key:@"forceFullscreen"];
        if(ip.row==6)return [self switchCell:@"Show FPS" key:@"showFPS"];
    } else {
        if(ip.row==0)return [self switchCell:@"Touch input" key:@"touchInput"];
        if(ip.row==1)return [self switchCell:@"Virtual keypad" key:@"showKeypad"];
    }
    return c;
}
- (void)switchChanged:(UISwitch *)sw { NSArray *keys=@[@"preserveAspect",@"filtering",@"forceFullscreen",@"showFPS",@"touchInput",@"showKeypad"]; NSInteger i=sw.tag-100; if(i>=0&&i<(NSInteger)keys.count) self.profile[keys[i]]=@(sw.on); }
- (void)choose:(NSArray<NSString *> *)values current:(NSString *)current title:(NSString *)title handler:(void(^)(NSString *))handler source:(UIView *)source {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    for(NSString *v in values)[a addAction:[UIAlertAction actionWithTitle:v style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x){handler(v);[self.tableView reloadData];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]]; a.popoverPresentationController.sourceView=source;a.popoverPresentationController.sourceRect=source.bounds;[self presentViewController:a animated:YES completion:nil];
}
- (void)customResolution {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"Custom resolution" message:@"Width and height: 1–2048" preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *f){f.keyboardType=UIKeyboardTypeNumberPad;f.placeholder=@"Width";f.text=[self.profile[@"screenWidth"] stringValue];}];
    [a addTextFieldWithConfigurationHandler:^(UITextField *f){f.keyboardType=UIKeyboardTypeNumberPad;f.placeholder=@"Height";f.text=[self.profile[@"screenHeight"] stringValue];}];
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x){NSInteger w=[a.textFields[0].text integerValue],h=[a.textFields[1].text integerValue];self.profile[@"screenWidth"]=@(MAX(1,MIN(2048,w)));self.profile[@"screenHeight"]=@(MAX(1,MIN(2048,h)));[self.tableView reloadData];}]];[self presentViewController:a animated:YES completion:nil];
}
- (void)customScale {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"Scale percent" message:@"10–300" preferredStyle:UIAlertControllerStyleAlert];
    [a addTextFieldWithConfigurationHandler:^(UITextField *f){f.keyboardType=UIKeyboardTypeNumberPad;f.text=[self.profile[@"scalePercent"] stringValue];}];
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *x){NSInteger v=[a.textFields[0].text integerValue];self.profile[@"scalePercent"]=@(MAX(10,MIN(300,v)));[self.tableView reloadData];}]];[self presentViewController:a animated:YES completion:nil];
}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)ip { [t deselectRowAtIndexPath:ip animated:YES]; UIView *src=[t cellForRowAtIndexPath:ip];
    if(ip.section==0&&ip.row==0){[self choose:J2MEResolutionPresets() current:@"" title:@"Resolution" handler:^(NSString *v){NSArray *p=[v componentsSeparatedByString:@"×"];self.profile[@"screenWidth"]=@([p[0] integerValue]);self.profile[@"screenHeight"]=@([p[1] integerValue]);} source:src];return;}
    if(ip.section==0&&ip.row==1){[self customResolution];return;}
    if(ip.section==0&&ip.row==2){id w=self.profile[@"screenWidth"];self.profile[@"screenWidth"]=self.profile[@"screenHeight"];self.profile[@"screenHeight"]=w;[t reloadData];return;}
    if(ip.section==0&&ip.row==3){[self customScale];return;}
    if(ip.section==1&&ip.row==0){[self choose:J2MEScaleTypes() current:self.profile[@"scaleType"] title:@"Scale type" handler:^(NSString *v){self.profile[@"scaleType"]=v;} source:src];return;}
    if(ip.section==1&&ip.row==2){[self choose:J2MEOrientations() current:self.profile[@"orientation"] title:@"Orientation" handler:^(NSString *v){self.profile[@"orientation"]=v;} source:src];return;}
    if(ip.section==1&&ip.row==3){[self choose:J2MEGravities() current:self.profile[@"gravity"] title:@"Gravity" handler:^(NSString *v){self.profile[@"gravity"]=v;} source:src];return;}
}
@end
