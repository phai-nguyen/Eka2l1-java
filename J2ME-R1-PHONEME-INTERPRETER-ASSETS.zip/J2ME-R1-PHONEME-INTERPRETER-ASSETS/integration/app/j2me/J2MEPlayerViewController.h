#pragma once
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@interface J2MEPlayerViewController : UIViewController
- (instancetype)initWithGame:(NSDictionary *)game profile:(NSDictionary *)profile;
@end
NS_ASSUME_NONNULL_END
