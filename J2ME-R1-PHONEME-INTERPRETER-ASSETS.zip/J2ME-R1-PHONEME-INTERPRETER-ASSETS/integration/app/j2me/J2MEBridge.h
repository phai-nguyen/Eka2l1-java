#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace eka2l1::ios::j2me {

struct Frame {
    int width = 0;
    int height = 0;
    std::uint64_t generation = 0;
    std::vector<std::uint8_t> rgba;
};

bool initialize(const std::string &runtime_home, std::string *error);
void shutdown();
bool install_jar(const std::string &jar_path, const std::string &scope,
                 std::int32_t &suite_id, std::string *error);
bool launch(std::int32_t suite_id, const std::string &main_class,
            std::int32_t app_id, int logical_width, int logical_height,
            std::string *error);
bool set_resolution(std::int32_t app_id, int logical_width, int logical_height,
                    std::string *error);
void send_key(std::int32_t key_code, bool pressed);
void send_pointer(int x, int y, int action);
bool copy_frame(Frame &frame, std::string *error);
void pump_events();
void flush_rms();
void pause(std::int32_t app_id);
void resume(std::int32_t app_id);
void destroy_midlet(std::int32_t app_id);

} // namespace eka2l1::ios::j2me
