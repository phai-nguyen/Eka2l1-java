#pragma once
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSDictionary * _Nullable J2MEInspectJarAtPath(NSString *path, NSError **error);
NS_ASSUME_NONNULL_END
