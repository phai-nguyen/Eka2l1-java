#import "J2MEProfileStore.h"

static NSURL *J2MEBaseURL(void) {
    NSURL *docs=[[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] firstObject];
    return [docs URLByAppendingPathComponent:@"j2me-phoneME" isDirectory:YES];
}
static NSURL *J2MEProfilesURL(void) { return [J2MEBaseURL() URLByAppendingPathComponent:@"profiles" isDirectory:YES]; }

NSMutableDictionary *J2MEDefaultProfile(void) {
    return [@{@"screenWidth":@240,@"screenHeight":@320,@"preserveAspect":@YES,@"scalePercent":@100,
              @"orientation":@"Default",@"gravity":@"Top",@"scaleType":@"Fit",@"filtering":@NO,
              @"forceFullscreen":@NO,@"showFPS":@NO,@"touchInput":@YES,@"showKeypad":@YES} mutableCopy];
}
NSMutableDictionary *J2MELoadProfile(NSString *gameID) {
    NSMutableDictionary *p=J2MEDefaultProfile();
    NSURL *u=[J2MEProfilesURL() URLByAppendingPathComponent:[gameID stringByAppendingPathExtension:@"json"]];
    NSData *d=[NSData dataWithContentsOfURL:u];
    if (d) {
        NSDictionary *saved=[NSJSONSerialization JSONObjectWithData:d options:0 error:nil];
        if ([saved isKindOfClass:NSDictionary.class]) [p addEntriesFromDictionary:saved];
    }
    return p;
}
BOOL J2MESaveProfile(NSString *gameID, NSDictionary *profile, NSError **error) {
    [[NSFileManager defaultManager] createDirectoryAtURL:J2MEProfilesURL() withIntermediateDirectories:YES attributes:nil error:error];
    if (error && *error) return NO;
    NSData *d=[NSJSONSerialization dataWithJSONObject:profile options:NSJSONWritingPrettyPrinted error:error];
    if (!d) return NO;
    NSURL *u=[J2MEProfilesURL() URLByAppendingPathComponent:[gameID stringByAppendingPathExtension:@"json"]];
    return [d writeToURL:u options:NSDataWritingAtomic error:error];
}
NSString *J2MEProfileSummary(NSDictionary *p) {
    return [NSString stringWithFormat:@"%@×%@ · %@ · %@%%",p[@"screenWidth"],p[@"screenHeight"],p[@"scaleType"],p[@"scalePercent"]];
}
