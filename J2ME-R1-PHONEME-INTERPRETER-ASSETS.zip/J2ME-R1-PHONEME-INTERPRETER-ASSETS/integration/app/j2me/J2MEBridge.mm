#include "J2MEBridge.h"
#include <PhoneMECore.h>
#include <algorithm>
#include <mutex>

namespace eka2l1::ios::j2me {
namespace {
std::mutex g_mutex;
PhoneMERuntimeRef g_runtime = nullptr;
std::uint64_t g_generation = 0;

std::string last_error(std::int32_t app_id = 0) {
    if (!g_runtime) return "phoneME runtime is not initialized";
    auto read = [&](bool app) -> std::string {
        int n = app ? phoneme_copy_midlet_error_message(g_runtime, app_id, nullptr, 0)
                    : phoneme_copy_last_error_message(g_runtime, nullptr, 0);
        if (n <= 0) return {};
        std::string s(static_cast<std::size_t>(n) + 1, '\0');
        if (app) phoneme_copy_midlet_error_message(g_runtime, app_id, s.data(), static_cast<int>(s.size()));
        else phoneme_copy_last_error_message(g_runtime, s.data(), static_cast<int>(s.size()));
        s.resize(static_cast<std::size_t>(n));
        return s;
    };
    std::string s = app_id ? read(true) : std::string{};
    if (s.empty()) s = read(false);
    return s.empty() ? "unknown phoneME error" : s;
}

bool ok(int status, std::string *error, std::int32_t app_id = 0) {
    if (status == PHONEME_OK) return true;
    if (error) *error = last_error(app_id) + " (status=" + std::to_string(status) + ")";
    return false;
}
}

bool initialize(const std::string &home, std::string *error) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_runtime) return true;
    const std::uint32_t abi = phoneme_c_api_version();
    if ((abi >> 16u) != PHONEME_C_API_VERSION_MAJOR) {
        if (error) *error = "phoneME C ABI major mismatch";
        return false;
    }
    g_runtime = phoneme_create();
    if (!g_runtime) { if (error) *error = "phoneme_create failed"; return false; }
    if (!ok(phoneme_configure(g_runtime, home.c_str(), nullptr), error) ||
        !ok(phoneme_configure_jit(g_runtime, 0), error)) {
        phoneme_destroy(g_runtime); g_runtime = nullptr; return false;
    }
    // Nokia/Sony-Ericsson MIDP game-action defaults.
    if (!ok(phoneme_configure_keymap(g_runtime, -1, -2, -3, -4, -5, -6, -7), error)) {
        phoneme_destroy(g_runtime); g_runtime = nullptr; return false;
    }
    g_generation = 0;
    return true;
}

void shutdown() {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_runtime) return;
    phoneme_flush_rms(g_runtime);
    phoneme_stop(g_runtime);
    phoneme_destroy(g_runtime);
    g_runtime = nullptr;
    g_generation = 0;
}

bool install_jar(const std::string &jar, const std::string &scope,
                 std::int32_t &suite, std::string *error) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_runtime) { if (error) *error = "phoneME not initialized"; return false; }
    suite = 0;
    int st = scope.empty() ? phoneme_install_jar(g_runtime, jar.c_str(), &suite)
                           : phoneme_install_jar_scoped(g_runtime, jar.c_str(), scope.c_str(), &suite);
    if (!ok(st, error) || suite <= 0) return false;
    return ok(phoneme_set_suite_trust(g_runtime, suite, PHONEME_SUITE_TRUSTED), error);
}

bool launch(std::int32_t suite, const std::string &main_class, std::int32_t app_id,
            int w, int h, std::string *error) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_runtime) { if (error) *error = "phoneME not initialized"; return false; }
    if (!phoneme_is_running(g_runtime) && !ok(phoneme_start_system(g_runtime), error)) return false;
    // Native timing; 128 MiB matches phoneME GameProfile default.
    if (!ok(phoneme_configure_app_frame_pacing(g_runtime, app_id, 60, PHONEME_FRAME_PACING_NATIVE), error, app_id)) return false;
    if (!ok(phoneme_configure_app_heap(g_runtime, app_id, 128), error, app_id)) return false;
    if (!ok(phoneme_start_midlet(g_runtime, suite, main_class.c_str(), app_id,
                                 std::clamp(w,1,2048), std::clamp(h,1,2048)), error, app_id)) return false;
    g_generation = 0;
    return true;
}

bool set_resolution(std::int32_t app_id, int w, int h, std::string *error) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_runtime) return false;
    return ok(phoneme_set_foreground(g_runtime, app_id, std::clamp(w,1,2048), std::clamp(h,1,2048)), error, app_id);
}

void send_key(std::int32_t key, bool pressed) {
    std::lock_guard<std::mutex> lock(g_mutex); if (g_runtime) phoneme_send_key(g_runtime, key, pressed ? 1 : 0);
}
void send_pointer(int x, int y, int action) {
    std::lock_guard<std::mutex> lock(g_mutex); if (g_runtime) phoneme_send_pointer(g_runtime, x, y, action);
}

bool copy_frame(Frame &f, std::string *error) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_runtime) return false;
    int w=0,h=0; std::uint64_t gen=0;
    int need = phoneme_copy_frame_rgba_since(g_runtime, g_generation, nullptr, 0, &w, &h, &gen);
    if (need < 0) { if (error) *error = last_error(); return false; }
    if (need == 0) return false; // unchanged
    f.rgba.resize(static_cast<std::size_t>(need));
    int copied = phoneme_copy_frame_rgba_since(g_runtime, g_generation, f.rgba.data(),
                                               static_cast<int>(f.rgba.size()), &w, &h, &gen);
    if (copied <= 0) { if (error) *error = last_error(); return false; }
    f.width=w; f.height=h; f.generation=gen; g_generation=gen;
    return true;
}

void pump_events() { std::lock_guard<std::mutex> lock(g_mutex); if (g_runtime) phoneme_pump_events(g_runtime); }
void flush_rms() { std::lock_guard<std::mutex> lock(g_mutex); if (g_runtime) phoneme_flush_rms(g_runtime); }
void pause(std::int32_t id) { std::lock_guard<std::mutex> lock(g_mutex); if (g_runtime) phoneme_pause_midlet(g_runtime,id); }
void resume(std::int32_t id) { std::lock_guard<std::mutex> lock(g_mutex); if (g_runtime) phoneme_resume_midlet(g_runtime,id); }
void destroy_midlet(std::int32_t id) { std::lock_guard<std::mutex> lock(g_mutex); if (g_runtime) phoneme_destroy_midlet(g_runtime,id); }
}
