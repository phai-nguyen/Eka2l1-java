#pragma once
#include <string>
#include <unordered_map>

namespace eka2l1::ios::j2me {
struct JarMetadata {
    std::string name;
    std::string vendor;
    std::string version;
    std::string main_class;
    std::string profile;
    std::string configuration;
    std::string icon_path;
    std::unordered_map<std::string, std::string> properties;
};

bool inspect_jar(const std::string &path, JarMetadata &out, std::string &error);
}
