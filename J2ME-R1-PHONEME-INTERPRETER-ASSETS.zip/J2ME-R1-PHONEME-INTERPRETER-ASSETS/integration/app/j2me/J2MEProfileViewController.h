#pragma once
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@interface J2MEProfileViewController : UITableViewController
@property(nonatomic,strong) NSMutableDictionary *profile;
@property(nonatomic,copy) void (^onSave)(NSDictionary *profile);
@end
NS_ASSUME_NONNULL_END
