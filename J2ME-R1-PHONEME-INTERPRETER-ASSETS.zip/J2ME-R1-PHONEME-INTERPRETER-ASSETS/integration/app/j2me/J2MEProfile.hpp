#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <utility>

namespace eka2l1::ios::j2me {

enum class Orientation { Default, Auto, Portrait, Landscape };
enum class ScreenGravity { Left, Top, Center, Right, Bottom };
enum class ScaleType { AsIs, Fit, Fill };

struct Profile {
    int screen_width = 240;
    int screen_height = 320;
    bool preserve_aspect_ratio = true;
    int scale_percent = 100;
    Orientation orientation = Orientation::Default;
    ScreenGravity gravity = ScreenGravity::Top;
    ScaleType scale_type = ScaleType::Fit;
    bool filtering = false;
    bool force_fullscreen = false;
    bool show_fps = false;

    void normalize() {
        screen_width = std::clamp(screen_width, 1, 2048);
        screen_height = std::clamp(screen_height, 1, 2048);
        scale_percent = std::clamp(scale_percent, 10, 300);
    }
};

inline constexpr std::array<std::pair<int,int>, 8> kScreenPresets{{
    {128,128}, {128,160}, {132,176}, {176,220},
    {240,320}, {352,416}, {640,360}, {800,480}
}};

struct Size { double width = 0; double height = 0; };
struct Point { double x = 0; double y = 0; };
struct Rect { Point origin; Size size; };

inline Point aligned_origin(Size rendered, Size available, ScreenGravity gravity) {
    switch (gravity) {
    case ScreenGravity::Left:   return {0, (available.height-rendered.height)/2.0};
    case ScreenGravity::Top:    return {(available.width-rendered.width)/2.0, 0};
    case ScreenGravity::Center: return {(available.width-rendered.width)/2.0, (available.height-rendered.height)/2.0};
    case ScreenGravity::Right:  return {available.width-rendered.width, (available.height-rendered.height)/2.0};
    case ScreenGravity::Bottom: return {(available.width-rendered.width)/2.0, available.height-rendered.height};
    }
    return {};
}

inline Rect rendered_frame_rect(Size frame, Size available, const Profile &p,
                                bool strict_fit=false, bool force_fit=false) {
    const double fw = std::max(frame.width, 1.0), fh = std::max(frame.height, 1.0);
    Size rendered{};
    if (force_fit) {
        if (p.preserve_aspect_ratio) {
            const double s = std::min(available.width/fw, available.height/fh);
            rendered = {frame.width*s, frame.height*s};
        } else rendered = available;
    } else {
        switch (p.scale_type) {
        case ScaleType::AsIs: {
            const double s = p.scale_percent / 100.0;
            rendered = {frame.width*s, frame.height*s};
            break;
        }
        case ScaleType::Fit: {
            const double requested = std::max(p.scale_percent/100.0, 0.01);
            if (p.preserve_aspect_ratio) {
                const double ws = available.width/fw, hs = available.height/fh;
                const bool fit_width = !strict_fit && p.gravity == ScreenGravity::Top &&
                    frame.height >= frame.width && available.height >= available.width;
                const double fit = fit_width ? ws : std::min(ws, hs);
                const double s = fit * requested;
                rendered = {frame.width*s, frame.height*s};
            } else rendered = {available.width*requested, available.height*requested};
            break;
        }
        case ScaleType::Fill:
            if (p.preserve_aspect_ratio) {
                const double s = std::max(available.width/fw, available.height/fh);
                rendered = {frame.width*s, frame.height*s};
            } else rendered = available;
            break;
        }
    }
    return {aligned_origin(rendered, available, p.gravity), rendered};
}

inline bool map_touch_to_logical(Point touch, const Rect &r, int logical_w, int logical_h,
                                 int &out_x, int &out_y) {
    if (r.size.width <= 0 || r.size.height <= 0 || logical_w <= 0 || logical_h <= 0) return false;
    if (touch.x < r.origin.x || touch.y < r.origin.y ||
        touch.x >= r.origin.x+r.size.width || touch.y >= r.origin.y+r.size.height) return false;
    const double nx = (touch.x-r.origin.x)/r.size.width;
    const double ny = (touch.y-r.origin.y)/r.size.height;
    out_x = std::clamp(static_cast<int>(nx*logical_w), 0, logical_w-1);
    out_y = std::clamp(static_cast<int>(ny*logical_h), 0, logical_h-1);
    return true;
}

} // namespace eka2l1::ios::j2me
