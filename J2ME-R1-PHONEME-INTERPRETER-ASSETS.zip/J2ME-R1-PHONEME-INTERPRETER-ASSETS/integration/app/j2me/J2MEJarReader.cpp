#include "J2MEJarReader.hpp"
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <fstream>
#include <limits>
#include <sstream>
#include <string_view>
#include <vector>
#include <zlib.h>

namespace eka2l1::ios::j2me {
namespace {
constexpr std::uint32_t kEOCD = 0x06054b50u;
constexpr std::uint32_t kCentral = 0x02014b50u;
constexpr std::uint32_t kLocal = 0x04034b50u;
constexpr std::size_t kMaxJarBytes = 256u * 1024u * 1024u;
constexpr std::size_t kMaxManifestBytes = 256u * 1024u;
constexpr std::size_t kMaxClassBytes = 8u * 1024u * 1024u;

std::uint16_t u16(const std::vector<std::uint8_t> &b, std::size_t p) {
    return static_cast<std::uint16_t>(b[p] | (std::uint16_t(b[p + 1]) << 8));
}
std::uint32_t u32(const std::vector<std::uint8_t> &b, std::size_t p) {
    return std::uint32_t(b[p]) | (std::uint32_t(b[p + 1]) << 8) |
           (std::uint32_t(b[p + 2]) << 16) | (std::uint32_t(b[p + 3]) << 24);
}
bool range_ok(std::size_t p, std::size_t n, std::size_t size) {
    return p <= size && n <= size - p;
}
std::string lower_ascii(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return char(std::tolower(c)); });
    return s;
}
std::string trim(std::string s) {
    auto ws = [](unsigned char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n'; };
    while (!s.empty() && ws(static_cast<unsigned char>(s.front()))) s.erase(s.begin());
    while (!s.empty() && ws(static_cast<unsigned char>(s.back()))) s.pop_back();
    return s;
}

struct Entry {
    std::string name;
    std::uint16_t flags = 0;
    std::uint16_t method = 0;
    std::uint32_t compressed = 0;
    std::uint32_t uncompressed = 0;
    std::uint32_t local_offset = 0;
};

bool read_file(const std::string &path, std::vector<std::uint8_t> &out, std::string &error) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { error = "Unable to open JAR"; return false; }
    const auto end = f.tellg();
    if (end < 0 || static_cast<std::uint64_t>(end) > kMaxJarBytes) { error = "JAR is too large"; return false; }
    out.resize(static_cast<std::size_t>(end));
    f.seekg(0);
    if (!out.empty() && !f.read(reinterpret_cast<char *>(out.data()), static_cast<std::streamsize>(out.size()))) {
        error = "Unable to read JAR"; return false;
    }
    return true;
}

bool list_entries(const std::vector<std::uint8_t> &b, std::vector<Entry> &entries, std::string &error) {
    if (b.size() < 22) { error = "Invalid ZIP/JAR"; return false; }
    const std::size_t floor = b.size() > (65535u + 22u) ? b.size() - (65535u + 22u) : 0u;
    std::size_t eocd = std::numeric_limits<std::size_t>::max();
    for (std::size_t p = b.size() - 22u;; --p) {
        if (range_ok(p, 4, b.size()) && u32(b, p) == kEOCD) { eocd = p; break; }
        if (p == floor) break;
    }
    if (eocd == std::numeric_limits<std::size_t>::max()) { error = "ZIP end record not found"; return false; }
    if (!range_ok(eocd, 22, b.size())) { error = "Truncated ZIP end record"; return false; }
    const auto count = u16(b, eocd + 10);
    const auto cd_size = u32(b, eocd + 12);
    const auto cd_off = u32(b, eocd + 16);
    if (!range_ok(cd_off, cd_size, b.size())) { error = "Invalid central directory"; return false; }
    std::size_t p = cd_off;
    entries.clear(); entries.reserve(count);
    for (std::uint32_t i = 0; i < count; ++i) {
        if (!range_ok(p, 46, b.size()) || u32(b, p) != kCentral) { error = "Invalid ZIP central entry"; return false; }
        Entry e;
        e.flags = u16(b, p + 8); e.method = u16(b, p + 10);
        e.compressed = u32(b, p + 20); e.uncompressed = u32(b, p + 24);
        const auto name_len = u16(b, p + 28), extra_len = u16(b, p + 30), comment_len = u16(b, p + 32);
        e.local_offset = u32(b, p + 42);
        if (!range_ok(p + 46, std::size_t(name_len) + extra_len + comment_len, b.size())) { error = "Truncated ZIP central entry"; return false; }
        e.name.assign(reinterpret_cast<const char *>(&b[p + 46]), name_len);
        if (e.name.find("../") != std::string::npos || (!e.name.empty() && (e.name[0] == '/' || e.name[0] == '\\'))) {
            error = "Unsafe JAR path"; return false;
        }
        entries.push_back(std::move(e));
        p += 46u + name_len + extra_len + comment_len;
    }
    return true;
}

bool extract_entry(const std::vector<std::uint8_t> &b, const Entry &e, std::size_t limit,
                   std::vector<std::uint8_t> &out, std::string &error) {
    if ((e.flags & 1u) != 0u) { error = "Encrypted JAR entries are not supported"; return false; }
    if (e.uncompressed > limit) { error = "JAR entry exceeds size limit"; return false; }
    const std::size_t p = e.local_offset;
    if (!range_ok(p, 30, b.size()) || u32(b, p) != kLocal) { error = "Invalid ZIP local entry"; return false; }
    const auto name_len = u16(b, p + 26), extra_len = u16(b, p + 28);
    const std::size_t data = p + 30u + name_len + extra_len;
    if (!range_ok(data, e.compressed, b.size())) { error = "Truncated ZIP data"; return false; }
    if (e.method == 0) {
        if (e.compressed != e.uncompressed) { error = "Invalid stored ZIP entry"; return false; }
        out.assign(b.begin() + data, b.begin() + data + e.compressed);
        return true;
    }
    if (e.method != 8) { error = "Unsupported JAR compression method"; return false; }
    out.assign(e.uncompressed, 0);
    z_stream zs{};
    zs.next_in = const_cast<Bytef *>(reinterpret_cast<const Bytef *>(&b[data]));
    zs.avail_in = e.compressed;
    zs.next_out = reinterpret_cast<Bytef *>(out.data());
    zs.avail_out = e.uncompressed;
    if (inflateInit2(&zs, -MAX_WBITS) != Z_OK) { error = "Unable to initialize ZIP inflater"; return false; }
    const int rc = inflate(&zs, Z_FINISH);
    inflateEnd(&zs);
    if (rc != Z_STREAM_END || zs.total_out != e.uncompressed) { error = "Invalid deflated JAR entry"; return false; }
    return true;
}

const Entry *find_entry(const std::vector<Entry> &entries, std::string_view target) {
    const std::string want = lower_ascii(std::string(target));
    for (const auto &e : entries) if (lower_ascii(e.name) == want) return &e;
    return nullptr;
}

std::unordered_map<std::string,std::string> parse_manifest(const std::string &text) {
    std::unordered_map<std::string,std::string> p;
    std::istringstream ss(text); std::string line, key;
    while (std::getline(ss, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty()) break;
        if (!line.empty() && line[0] == ' ' && !key.empty()) { p[key] += line.substr(1); continue; }
        const auto colon = line.find(':');
        if (colon == std::string::npos) continue;
        key = trim(line.substr(0, colon));
        p[key] = trim(line.substr(colon + 1));
    }
    return p;
}
std::string property_ci(const std::unordered_map<std::string,std::string> &p, std::string_view key) {
    const auto want = lower_ascii(std::string(key));
    for (const auto &kv : p) if (lower_ascii(kv.first) == want) return kv.second;
    return {};
}
std::vector<std::string> csv3(const std::string &s) {
    std::vector<std::string> v; std::size_t start=0;
    for (int i=0;i<2;i++) { auto pos=s.find(',',start); if(pos==std::string::npos) return {}; v.push_back(trim(s.substr(start,pos-start))); start=pos+1; }
    v.push_back(trim(s.substr(start))); return v;
}
}

bool inspect_jar(const std::string &path, JarMetadata &out, std::string &error) {
    std::vector<std::uint8_t> bytes; if (!read_file(path, bytes, error)) return false;
    std::vector<Entry> entries; if (!list_entries(bytes, entries, error)) return false;
    const Entry *mf = find_entry(entries, "META-INF/MANIFEST.MF");
    if (!mf) { error = "META-INF/MANIFEST.MF not found"; return false; }
    std::vector<std::uint8_t> manifest; if (!extract_entry(bytes, *mf, kMaxManifestBytes, manifest, error)) return false;
    const auto props = parse_manifest(std::string(reinterpret_cast<const char *>(manifest.data()), manifest.size()));
    const auto midlet1 = property_ci(props, "MIDlet-1");
    const auto parts = csv3(midlet1);
    if (parts.size() != 3 || parts[2].empty()) { error = "MIDlet-1 is missing or invalid"; return false; }
    std::string class_path = parts[2]; std::replace(class_path.begin(), class_path.end(), '.', '/'); class_path += ".class";
    const Entry *cls = find_entry(entries, class_path);
    if (!cls) { error = "MIDlet main class is missing from JAR"; return false; }
    std::vector<std::uint8_t> probe; if (!extract_entry(bytes, *cls, kMaxClassBytes, probe, error)) return false;
    if (probe.size() < 4 || probe[0] != 0xCA || probe[1] != 0xFE || probe[2] != 0xBA || probe[3] != 0xBE) {
        error = "MIDlet main class has invalid Java class magic"; return false;
    }
    out = {};
    out.properties = props;
    out.name = property_ci(props, "MIDlet-Name"); if (out.name.empty()) out.name = parts[0];
    out.vendor = property_ci(props, "MIDlet-Vendor");
    out.version = property_ci(props, "MIDlet-Version");
    out.profile = property_ci(props, "MicroEdition-Profile");
    out.configuration = property_ci(props, "MicroEdition-Configuration");
    out.main_class = parts[2]; out.icon_path = parts[1];
    return true;
}
}
