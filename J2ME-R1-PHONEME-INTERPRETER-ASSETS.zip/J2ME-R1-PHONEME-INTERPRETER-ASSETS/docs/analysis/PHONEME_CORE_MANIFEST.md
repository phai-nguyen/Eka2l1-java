# Exact libphoneMECore build boundary

Pinned upstream for J2ME R1: **phoneME v0.3.10-build10 / commit `90c9e12`**.

## What actually becomes `libphoneMECore.a`

The stock `Core/Tools/build-iphoneos.sh` compiles every `Core/src/**/*.cpp` with the `Core/include` tree and archives those objects into `libphoneMECore.a`. In this uploaded source snapshot:

- C++ translation units: **141**
- public/core headers: **77**
- Core C ABI: `PhoneMECore.h` ABI **1.3.0**
- C++ language for the archive: **C++23**
- target: `arm64-apple-ios15.0+`
- compile mode: `PHONEME_IPHONEOS_ONLY=1`, no RTTI, exceptions disabled except the source explicitly compiled with exceptions by the build script.

### Exact source directories required for compilation

```text
Core/include/**
Core/src/**
```

### Exact stock tooling required if we reuse phoneME's build/verification scripts

```text
Core/Tools/build-iphoneos.sh
Core/Tools/verify-iphoneos.sh
Core/Tools/lib/common-test-root.sh
Core/Tests/**     # scripts scan this tree for forbidden legacy/vendor dependencies
```

`Core/Compatibility`, `Core/Web`, `web/`, the SwiftUI app, and TrollStore/JIT frontend files are not needed to produce the iPhoneOS static Core archive.

## Important EKA2L1 integration rule

Do **not** add phoneME Core as a normal PUBLIC CMake target to EKA2L1. Its target advertises C++23; EKA2L1's native code is C++17. Build the archive separately, then link the `.a` through its stable **C ABI**. This isolates language-standard and compiler-option differences.

## Required app link flags

From phoneME's Xcode project:

```text
-lz
-liconv
-framework CoreText
-framework CoreGraphics
-framework CoreFoundation
-framework ImageIO
-Wl,-force_load,<path>/libphoneMECore.a
```

`-force_load` is retained deliberately so native/builtin registration objects are not discarded by static dead stripping.

## Files intentionally not copied into J2ME R1 runtime

```text
PhoneMETrollStoreJIT.m
phoneME SwiftUI frontend
phoneME app entitlements
JIT bootstrap / dynamic-codesigning machinery
```
