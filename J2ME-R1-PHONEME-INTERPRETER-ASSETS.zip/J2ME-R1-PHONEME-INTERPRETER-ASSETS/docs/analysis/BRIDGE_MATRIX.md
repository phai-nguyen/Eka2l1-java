# iOS bridge matrix for EKA2L1 J2ME R1

| Component | R1 status | Why | Extra frameworks |
|---|---|---|---|
| `PhoneMECore.h` C ABI | **Required** | only API EKA2L1 needs to call the C++23 runtime | none |
| New `J2MEBridge.mm` | **Required** | owns runtime lifecycle, JAR install/launch, input, framebuffer, RMS flush | Foundation through EKA2L1 app |
| New `J2MEProfile.hpp` + render math | **Required** | faithful port of phoneME logical resolution + presentation scaling | none |
| New JAR metadata adapter | **Required for library UI** | extract manifest, title/vendor/version/main class/icon before launch | use existing EKA2L1/miniz instead of importing Swift |
| `PhoneMEMediaBridge.m` | **R1.1 recommended** | MMAPI/audio/tone/vibration/backlight | AVFoundation, AVFAudio, AudioToolbox, MediaPlayer, UIKit |
| `PhoneMEHTTPSBridge.m` | **R1.1 optional** | HTTPS host transport | Foundation, Security |
| `PhoneMEMetal3DBridge.mm` | **R2 optional** | Metal raster acceleration; Core has non-Metal path | Metal |
| `PhoneMEPlatformBridge.m` | **Defer** | platformRequest host behavior; not needed for first offline game boot | UIKit |
| `PhoneMETrollStoreJIT.m` | **Excluded** | R1 is interpreter-only | would require JIT/private entitlement work |

The uploaded interpreter TIPA has `PhoneMEInterpreterOnly=true` and `PhoneMETrollStoreJIT=false`, validating the no-JIT plan.
