# J2ME R1 — complete screen-resolution and presentation profile

This specification intentionally preserves the two independent layers in phoneME.

## Layer A — logical MIDlet resolution (guest-visible)

Defaults:

```text
width  = 240
height = 320
valid range per dimension = 1..2048
```

The values are passed directly to:

```c
phoneme_start_midlet(..., screen_width, screen_height)
phoneme_set_foreground(..., screen_width, screen_height)
```

So changing 176×220 to 240×320 changes what Java `Display`/Canvas sees; it is not merely zoom.

### Exact phoneME preset list

```text
128 × 128
128 × 160
132 × 176
176 × 220
240 × 320
352 × 416
640 × 360
800 × 480
Custom width × height
```

R1 UI must also have **Swap width/height**.

## Layer B — iPhone presentation of the framebuffer

Profile fields retained from phoneME:

```text
preserveAspectRatio = true
scalePercent        = 100        # clamp 10..300
orientation         = default | auto | portrait | landscape
screenGravity       = left | top | center | right | bottom
scaleType           = asIs | fit | fill
filtering           = false
forceFullscreen     = false
showFPS             = false
```

### Scale modes

**As-is**

```text
renderedWidth  = framebufferWidth  × scalePercent/100
renderedHeight = framebufferHeight × scalePercent/100
```

**Fit**

When aspect ratio is preserved, calculate width and height scales. Normally use the smaller. phoneME has one intentional compatibility special-case: if `strictFit=false`, gravity is `top`, both guest and host are portrait, fit to host **width**. Multiply that fit scale by `scalePercent/100`.

When aspect ratio is not preserved:

```text
renderedWidth  = availableWidth  × scalePercent/100
renderedHeight = availableHeight × scalePercent/100
```

**Fill**

With aspect preservation, use the larger of widthScale/heightScale so the framebuffer covers the window (cropping may occur). Without aspect preservation use the full available rectangle.

### Force-fit

When the host requires `forceFit`, ignore scale type/percent. Preserve aspect with `min(widthScale,heightScale)` or occupy the whole available rectangle when aspect preservation is disabled.

### Gravity

```text
left:   x=0;                         y=(AH-RH)/2
top:    x=(AW-RW)/2;                 y=0
center: x=(AW-RW)/2;                 y=(AH-RH)/2
right:  x=AW-RW;                     y=(AH-RH)/2
bottom: x=(AW-RW)/2;                 y=AH-RH
```

### Filtering

- `false`: nearest-neighbor / crisp pixel scaling
- `true`: linear filtering

### Touch coordinate transform

Touch must be converted from the displayed rectangle back to logical MIDlet coordinates:

```text
logicalX = (touchX - renderRect.x) × logicalWidth  / renderRect.width
logicalY = (touchY - renderRect.y) × logicalHeight / renderRect.height
```

Clamp to `[0,width-1]` / `[0,height-1]` before `phoneme_send_pointer`. Touches outside the rendered rectangle are ignored unless a future profile explicitly requests edge clamping.

## Why the two layers must never be merged

Example: a 176×220 Nokia game rendered on an iPhone may use logical `176×220` but presentation `Fit, 130%, top, preserve aspect`. The MIDlet must still receive 176×220 and touch coordinates in that coordinate space. Changing presentation scale must not restart the VM; changing logical resolution should call `phoneme_set_foreground` (or restart when a title does not tolerate resize).
