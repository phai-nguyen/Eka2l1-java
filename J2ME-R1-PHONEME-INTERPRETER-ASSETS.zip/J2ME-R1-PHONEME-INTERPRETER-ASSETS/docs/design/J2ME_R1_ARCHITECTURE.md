# EKA2L1 iOS — J2ME R1 PHONEME INTERPRETER architecture

## Isolation goal

J2ME R1 is **additive**. It must not edit the R3 RM612 CODEMAP1 implementation (`control.cpp`, `libmanager.cpp`) or change the Symbian/N-Gage execution path. The current R3 workflow remains a frozen baseline. A new workflow derives from it and adds phoneME only after all R3 patch steps have completed.

## Runtime split

```text
EKA2L1.app
├── Symbian engine (existing EKA2L1)
│   └── SIS/SISX/N-Gage
└── Java engine (new)
    └── libphoneMECore.a — interpreter only
        └── JAR / CLDC / MIDP
```

No Java execution is routed through Symbian, KMidRun, C6-00, or 5320 firmware.

## R1 C ABI lifecycle

1. Assert `phoneme_c_api_version()` major == 1 (snapshot is 1.3.0).
2. `phoneme_create()`
3. `phoneme_configure(runtime, <Documents>/j2me-phoneME/runtime, NULL)`
4. `phoneme_configure_jit(runtime, 0)` — hard requirement for R1.
5. Import JAR metadata into EKA2L1 Java library.
6. `phoneme_install_jar_scoped(runtime, jar, gameUUID, &suiteID)`
7. `phoneme_set_suite_trust(..., PHONEME_SUITE_TRUSTED)`
8. If not running: `phoneme_start_system(runtime)`
9. Configure Nokia keymap.
10. Configure app frame pacing/heap (default native timing; 128 MiB profile default).
11. `phoneme_start_midlet(..., logicalWidth, logicalHeight)`
12. Poll/pump frame and LCDUI events. Canvas initially uses copied RGBA; optimize later to native BGRA zero-copy.
13. Map keypad/touch to `phoneme_send_key`/`phoneme_send_pointer`.
14. On background/memory warning: `phoneme_flush_rms`, then pause/suspend as appropriate.
15. On exit: `phoneme_destroy_midlet`; retain shared runtime for next JAR, or `phoneme_stop` + `phoneme_destroy` on app teardown.

## Storage boundary

Keep phoneME storage outside all Symbian device profiles:

```text
Documents/
└── j2me-phoneME/
    ├── runtime/              # phoneME SuiteStore/RMS/FileConnection
    ├── library/
    │   └── <game-uuid>/
    │       ├── app.jar
    │       ├── metadata.json
    │       └── icon.*
    └── profiles/
        └── <game-uuid>.json
```

Switching C6/5320/N-Gage firmware cannot modify or delete Java saves.

## Java library UI

Do not mix JARs into Symbian package registry. Add a Java library mode/tab inside the existing UIKit app. The document picker accepts `.jar`, validates manifest, stores it, then displays title/icon/vendor/version.

Recommended top-level UX:

```text
Apps
├── Symbian
└── Java

Install Game
├── SIS/SISX/N-Gage (existing)
└── Java JAR (new)
```

## JAR metadata and safety

Port the behavior of `JarMetadataReader.swift`, but implement it in EKA2L1 Objective-C++/C++ using existing miniz so Swift is not introduced. Validate:

- `META-INF/MANIFEST.MF`
- MIDlet-Name/Vendor/Version
- MicroEdition-Profile: MIDP-1.0/2.0/2.1
- MicroEdition-Configuration: CLDC-1.0/1.1/1.1.1
- contiguous MIDlet-1...MIDlet-N
- selected main class exists and starts with class magic `CAFEBABE`
- safe ZIP paths, no encrypted entries, bounded decompression, CRC validation

## Input baseline

Nokia/SE keymap:

```text
UP=-1 DOWN=-2 LEFT=-3 RIGHT=-4 FIRE=-5 SOFT1=-6 SOFT2=-7
0..9 = ASCII 48..57; *=42; #=35
```

R1 should also preserve the phoneME profile concept so Siemens/Motorola/custom mapping can be added without changing Core.

## R1 PASS gates

```text
Core archive builds + verify script PASS
phoneME ABI 1.x detected
JIT forced OFF
JAR manifest parsed
JAR installs and yields suiteID
system starts
MIDlet reaches ACTIVE
nonblank Canvas frame produced
resolution preset and custom dimensions work
As-is/Fit/Fill + gravity + 10..300% scale behave correctly
touch mapping reaches correct logical coordinates
Nokia keypad works
RMS survives app restart
Symbian/N-Gage R3 regression remains unchanged
```
