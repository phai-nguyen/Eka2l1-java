# J2ME R1 PHONEME INTERPRETER build assets

Self-contained assets for the companion EKA2L1 iOS GitHub Actions workflow.

- phoneME source pin: v0.3.10-build10 / commit 90c9e12
- C API: 1.3.0
- phoneME Core: C++23, iOS arm64, iOS 15+
- EKA2L1 integration: Objective-C++ / C++17, C ABI only
- JIT: disabled at runtime (interpreter R1)
- EKA2L1 R3 RM612 CODEMAP1: preserved; J2ME is additive
- JAR metadata reader: separate C++17 ZIP/manifest reader using zlib, so no C++23 phoneME internal headers leak into EKA2L1

## Repository placement
Put this ZIP at the repository root as `J2ME-R1-PHONEME-INTERPRETER-ASSETS.zip` and put the companion `.yml` in `.github/workflows/`.

## Resolution/profile mechanism
Logical MIDlet screen presets: 128x128, 128x160, 132x176, 176x220, 240x320, 352x416, 640x360, 800x480; custom 1..2048; width/height swap.

Presentation controls: As-is/Fit/Fill, 10..300% Canvas scale, preserve aspect ratio, Default/Auto/Portrait/Landscape orientation, Left/Top/Center/Right/Bottom gravity, image filtering, force fullscreen, touch input and virtual keypad. Logical resolution is passed to phoneME; presentation scaling is host-only.
